import './style.css'
import PerfilImg from '../../assets/perfil.png'

import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

import {
  FaUser,
  FaIdCard,
  FaPhone,
  FaEnvelope,
  FaRunning,
  FaBell,
  FaLock,
  FaShieldAlt,
  FaSignOutAlt,
  FaSave,
  FaChevronRight
} from "react-icons/fa";

function Perfil() {

  const navigate = useNavigate();

  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");
  const tipo = Number(localStorage.getItem("tipo"));

  const [nome, setNome] = useState("");
  const [ra, setRa] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [esporte1, setEsporte1] = useState("");
  const [esporte2, setEsporte2] = useState("");
  const [esporte3, setEsporte3] = useState("");
  const [notifPartidas, setNotifPartidas] = useState(false);
  const [notifTempo, setNotifTempo] = useState(false);

  function handleUserClick() {

    if (token) {
      navigate("/perfil");
    } else {
      navigate("/login");
    }
  }

  function logout() {

    localStorage.removeItem("token");
    localStorage.removeItem("user");
    localStorage.removeItem("tipo");

    navigate("/login");
  }

  async function carregarPerfil() {

    try {

      const response = await axios.get(
        `http://localhost:3000/perfil/${token}`
      );

      setNome(response.data.nome || "");
      setRa(response.data.ra || "");
      setTelefone(response.data.telefone || "");
      setEmail(response.data.email_pessoal || "");
      setEsporte1(response.data.esporte1 || "");
      setEsporte2(response.data.esporte2 || "");
      setEsporte3(response.data.esporte3 || "");
      setNotifPartidas(response.data.notif_partidas === 1);
      setNotifTempo(response.data.notif_tempo === 1);

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao carregar perfil"
      );
    }
  }

  async function salvarPerfil() {

    try {

      await axios.put(
        `http://localhost:3000/perfil/${token}`,
        {
          nome,
          telefone,
          esporte1,
          esporte2,
          esporte3,
          email_pessoal: email,
          notif_partidas: notifPartidas ? 1 : 0,
          notif_tempo: notifTempo ? 1 : 0
        }
      );

      localStorage.setItem("user", nome);

      alert("Perfil atualizado!");

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao salvar perfil"
      );
    }
  }

  async function alterarSenha() {

    const novaSenha = prompt("Digite a nova senha");

    if (!novaSenha) return;

    try {

      await axios.put(
        `http://localhost:3000/alterar-senha/${token}`,
        {
          senha: novaSenha
        }
      );

      alert("Senha alterada!");

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao alterar senha"
      );
    }
  }

  useEffect(() => {

    if (!token) {

      navigate("/login");
      return;
    }

    carregarPerfil();

  }, []);

  return (
    <>
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">
         

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      

      <div className="perfil-container">

        

        <div className="perfil-card">

          {/* LEFT */}
          <div className="perfil-left">

            <div className="perfil-img">
              <img src={PerfilImg} alt="perfil"/>
            </div>

            {
              tipo === 2 && (
                <div className="master-badge">
                  <FaShieldAlt />
                  MASTER ADMIN
                </div>
              )
            }

            <label>Nome</label>

            <div className="input-icon">
              <FaUser />
              <input
                value={nome}
                onChange={(e) =>
                  setNome(e.target.value)
                }
              />
            </div>

            <label>RA</label>

            <div className="input-icon">
              <FaIdCard />
              <input
                value={ra}
                disabled
              />
            </div>

            <button
              className="btn-senha"
              onClick={alterarSenha}
            >
              <FaLock />
              ALTERAR SENHA
              <FaChevronRight />
            </button>

          </div>

          {/* MIDDLE */}
          <div className="perfil-middle">

            <h2>
              <FaRunning />
              ESPORTES PREFERIDOS
            </h2>

            <label>Esporte Preferido 1</label>

            <select
              value={esporte1}
              onChange={(e) =>
                setEsporte1(e.target.value)
              }
            >
              <option value="">Selecione</option>
              <option value="Futsal">Futsal</option>
              <option value="Basquete">Basquete</option>
              <option value="Vôlei">Vôlei</option>
              <option value="Handebol">Handebol</option>
            </select>

            <label>Esporte Preferido 2</label>

            <select
              value={esporte2}
              onChange={(e) =>
                setEsporte2(e.target.value)
              }
            >
              <option value="">Selecione</option>
              <option value="Futsal">Futsal</option>
              <option value="Basquete">Basquete</option>
              <option value="Vôlei">Vôlei</option>
              <option value="Handebol">Handebol</option>
            </select>

            <label>Esporte Preferido 3</label>

            <select
              value={esporte3}
              onChange={(e) =>
                setEsporte3(e.target.value)
              }
            >
              <option value="">Selecione</option>
              <option value="Futsal">Futsal</option>
              <option value="Basquete">Basquete</option>
              <option value="Vôlei">Vôlei</option>
              <option value="Handebol">Handebol</option>
            </select>

            <div className="dica-card">

              <h3>Dica</h3>

              <p>
                Sempre faça Logout em dispositivos que não sejam pessoais. 
              </p>

            </div>

          </div>

          {/* RIGHT */}
          <div className="perfil-right">

            <h2>
              <FaPhone />
              CONTATO
            </h2>

            <label>Telefone</label>

            <div className="input-icon">
              <FaPhone />
              <input
                value={telefone}
                onChange={(e) =>
                  setTelefone(e.target.value)
                }
              />
            </div>

            <label>Email Pessoal</label>

            <div className="input-icon">
              <FaEnvelope />
              <input
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
              />
            </div>

            <div className="linha"></div>

            <h2>
              <FaBell />
              NOTIFICAÇÕES
            </h2>

            <div className="toggle-card">

              <div>
                <strong>Novas partidas</strong>

                <p>
                  Receba notificações sobre
                  novas partidas disponíveis.
                </p>
              </div>

              <input
                type="checkbox"
                checked={notifPartidas}
                onChange={(e) =>
                  setNotifPartidas(
                    e.target.checked
                  )
                }
              />

            </div>

            <div className="toggle-card">

              <div>
                <strong>Aviso de horário</strong>

                <p>
                  Receba lembretes antes
                  do seu horário agendado.
                </p>
              </div>

              <input
                type="checkbox"
                checked={notifTempo}
                onChange={(e) =>
                  setNotifTempo(
                    e.target.checked
                  )
                }
              />

            </div>

            {
              tipo >= 1 && (

                <div
                  className="admin-card"
                  onClick={() => navigate("/adm")}
                >

                  <div>

                    <h3>
                      <FaShieldAlt />
                      PAINEL ADMINISTRATIVO
                    </h3>

                    <p>
                      Gerencie usuários,
                      quadras e agendamentos
                    </p>

                  </div>

                  <FaChevronRight />

                </div>
              )
            }

            <div className="botoes">

              <button
                className="logout"
                onClick={logout}
              >
                <FaSignOutAlt />
                LOGOUT
              </button>

              <button
                className="salvar"
                onClick={salvarPerfil}
              >
                <FaSave />
                SALVAR ALTERAÇÕES
              </button>

            </div>

          </div>

        </div>

      </div>

      
    </>
  )
}

export default Perfil;