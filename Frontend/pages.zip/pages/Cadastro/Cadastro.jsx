import './style.css'

import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";
import Perfil from '../../assets/perfil.png'

function Cadastro() {

  const navigate = useNavigate();

  // STATES
  const [nome, setNome] = useState("");
  const [ra, setRa] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [confirmarSenha, setConfirmarSenha] = useState("");
  const [telefone, setTelefone] = useState("");
  const [esporte1, setEsporte1] = useState("");
  const [esporte2, setEsporte2] = useState("");
  const [esporte3, setEsporte3] = useState("");

  // LOGIN INTELIGENTE
  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");

  function handleUserClick() {

    if (token) {
      navigate("/perfil");
    } else {
      navigate("/login");
    }
  }

  // CADASTRAR
  async function handleCadastro() {

    if (
      !nome ||
      !ra ||
      !email ||
      !senha ||
      !confirmarSenha
    ) {

      alert("Preencha todos os campos");
      return;

    }

    if (senha !== confirmarSenha) {

      alert("As senhas não coincidem");
      return;

    }

    try {

      const response = await axios.post(
        "http://localhost:3000/cadastro",
        {
          nome,
          ra,
          email,
          senha,
          telefone,
          esporte1,
          esporte2,
          esporte3
        }
      );

      alert(response.data);

      navigate("/login");

    } catch (error) {

      console.error(error);

      alert(
        error.response?.data ||
        "Erro ao cadastrar"
      );

    }
  }

  return (
    <>
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CADASTRO */}
      <div className="cadastro-container">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>


        <h1 style={{ marginBottom: "20px" }}>
          Cadastro de Usuário
        </h1>

        <div className="cadastro-box">

          <div className="form-grid">

            {/* NOME */}
            <div className="form-group">

              <label>Nome:</label>

              <input
                type="text"
                value={nome}
                onChange={(e) =>
                  setNome(e.target.value)
                }
              />

            </div>

            {/* EMAIL */}
            <div className="form-group">

              <label>E-mail:</label>

              <input
                type="email"
                value={email}
                onChange={(e) =>
                  setEmail(e.target.value)
                }
              />

            </div>

            {/* RA */}
            <div className="form-group">

              <label>Registro:</label>

              <input
                type="text"
                value={ra}
                onChange={(e) =>
                  setRa(e.target.value)
                }
              />

            </div>

            {/* TELEFONE */}
            <div className="form-group">

              <label>Telefone:</label>

              <input
                type="text"
                value={telefone}
                onChange={(e) =>
                  setTelefone(e.target.value)
                }
              />

            </div>

            {/* SENHA */}
            <div className="form-group">

              <label>Senha:</label>

              <input
                type="password"
                value={senha}
                onChange={(e) =>
                  setSenha(e.target.value)
                }
              />

            </div>

            {/* CONFIRMAR SENHA */}
            <div className="form-group">

              <label>Confirmar Senha:</label>

              <input
                type="password"
                value={confirmarSenha}
                onChange={(e) =>
                  setConfirmarSenha(
                    e.target.value
                  )
                }
              />

            </div>

            {/* REGRAS */}
            <div className="senha-regras-box">

              <div className="senha-regras">

                <div>* 1 Maiúscula</div>

                <div>* 1 minúscula</div>

                <div>* 1 número</div>

                <div>* 1 especial</div>

                <div>* 8–12 caracteres</div>

              </div>

            </div>

            {/* ESPORTE 1 */}
            <div className="form-group">

              <label>Esporte 1:</label>

              <select
                value={esporte1}
                onChange={(e) =>
                  setEsporte1(e.target.value)
                }
              >

                <option value="">
                  Selecione
                </option>

                <option value="Futsal">
                  Futsal
                </option>

                <option value="Basquete">
                  Basquete
                </option>

                <option value="Vôlei">
                  Vôlei
                </option>

                <option value="Handebol">
                  Handebol
                </option>

              </select>

            </div>

            {/* ESPORTE 2 */}
            <div className="form-group">

              <label>Esporte 2:</label>

              <select
                value={esporte2}
                onChange={(e) =>
                  setEsporte2(e.target.value)
                }
              >

                <option value="">
                  Selecione
                </option>

                <option value="Futsal">
                  Futsal
                </option>

                <option value="Basquete">
                  Basquete
                </option>

                <option value="Vôlei">
                  Vôlei
                </option>

                <option value="Handebol">
                  Handebol
                </option>

              </select>

            </div>

            {/* ESPORTE 3 */}
            <div className="form-group">

              <label>Esporte 3:</label>

              <select
                value={esporte3}
                onChange={(e) =>
                  setEsporte3(e.target.value)
                }
              >

                <option value="">
                  Selecione
                </option>

                <option value="Futsal">
                  Futsal
                </option>

                <option value="Basquete">
                  Basquete
                </option>

                <option value="Vôlei">
                  Vôlei
                </option>

                <option value="Handebol">
                  Handebol
                </option>

              </select>

            </div>

          </div>

          <button onClick={handleCadastro}>
            Cadastrar
          </button>

        </div>

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>
    </>
  )
}

export default Cadastro;