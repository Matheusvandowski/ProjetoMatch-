import './style.css'
import { Link, useNavigate } from "react-router-dom";
import Perfil from '../../assets/perfil.png'
import { useState } from "react";

function ReportarAtividades() {

  const [valor, setValor] = useState("");
  const [descricao, setDescricao] = useState("");

  const navigate = useNavigate();

  // 🔐 dados do login
  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  async function handleSubmit(e) {

    e.preventDefault();

    if (!valor || !descricao) {

      alert("Preencha todos os campos");

      return;

    }

    try {

      const response = await fetch(
        "http://localhost:3000/reportar-atividade",
        {

          method: "POST",

          headers: {

            "Content-Type": "application/json",

            Authorization:
              `Bearer ${token}`

          },

          body: JSON.stringify({

            tipo: valor,

            descricao

          })

        }
      );

      const data =
        await response.text();

      if (!response.ok) {

        throw new Error(data);

      }

      alert(
        "Atividade reportada com sucesso!"
      );

      setValor("");

      setDescricao("");

    } catch (err) {

      console.error(err);

      alert(
        err.message ||
        "Erro ao enviar reporte"
      );

    }

  }

  return (
    <>
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTEÚDO PRINCIPAL */}

      <div className="report-page">

        {/* TOPO */}

        <div className="top-section">

          <button
            className="button-back"
            onClick={() => navigate(-1)}
          >
            ← Voltar
          </button>

          <h1 className="page-title">
            Reportar Atividade
          </h1>

        </div>

        {/* CONTAINER DOS CARDS */}

        <div className="report-content">

          {/* CARD INFORMATIVO */}

          <div className="info-card">

            <h2>
              Como reportar uma atividade?
            </h2>

            <p>
              Para reportar uma atividade selecione uma opção:
            </p>

            <div className="info-topicos">

              <div className="info-item">

                <strong>
                  Instalações
                </strong>

                <span>
                  Se havia algum dano físico na quadra.
                </span>

              </div>

              <div className="info-item">

                <strong>
                  Reserva
                </strong>

                <span>
                  Se houve algum problema com a reserva em si, como horário.
                </span>

              </div>

              <div className="info-item">

                <strong>
                  Participante
                </strong>

                <span>
                  Se algum participante gerou algum incômodo.
                </span>

              </div>

              <div className="info-item">

                <strong>
                  Outro Problema
                </strong>

                <span>
                  Caso tenha tido algum problema que não se encaixe nos tópicos acima.
                </span>

              </div>

            </div>

            <div className="info-alerta">

              Não esqueça de descrever seu problema para que a administração possa te ajudar da melhor forma possível.

            </div>

          </div>

          {/* FORM */}

          <div className="container-select">

            <form
              className="form-box"
              onSubmit={handleSubmit}
            >

              <select
                value={valor}
                onChange={(e) =>
                  setValor(e.target.value)
                }
                className="select-box"
              >

                <option value="">
                  Selecione uma opção
                </option>

                <option value="Problema com as Instalações">
                  Problema com as Instalações
                </option>

                <option value="Problema com a Reserva">
                  Problema com a Reserva
                </option>

                <option value="Problema com algum participante">
                  Problema com algum participante
                </option>

                <option value="Outro problema">
                  Outro problema
                </option>

              </select>

              <textarea
                className="textarea-box"
                placeholder="Descreva sua reclamação..."
                value={descricao}
                onChange={(e) =>
                  setDescricao(e.target.value)
                }
              />

              <button
                type="submit"
                className="btn-enviar"
              >
                Enviar
              </button>

            </form>

          </div>

        </div>

      </div>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              F
            </a>

            <a href="#">
              Insta
            </a>

            <a href="#">
              LkdIn
            </a>

            <a href="#">
              YT
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>

    </>
  )
}

export default ReportarAtividades;