import './style.css'
import { Link } from "react-router-dom";
import { useState } from "react";
import Perfil from '../../assets/perfil.png'

function Senha() {

  const [form, setForm] = useState({
    email: "",
    confirmarEmail: "",
  });

  function handleChange(e) {
    const { name, value } = e.target;
    setForm({
      ...form,
      [name]: value
    });
  }

  function handleSubmit(e) {
    e.preventDefault();

    if (form.email !== form.confirmarEmail) {
      alert("E-mails não coincidem");
      return;
    }

    console.log(form);
    alert("Solicitação enviada!");
  }

  return (
    <>
      
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTEÚDO */}
      <div className="senha-container">

        <div className="senha-box">

          <h1>Recuperação de Senha</h1>
          <p>Informe seu e-mail institucional para recuperação</p>

          <form onSubmit={handleSubmit}>

            <input
              type="email"
              name="email"
              placeholder="Digite seu e-mail"
              value={form.email}
              onChange={handleChange}
              required
            />

            <input
              type="email"
              name="confirmarEmail"
              placeholder="Confirme seu e-mail"
              value={form.confirmarEmail}
              onChange={handleChange}
              required
            />

            <button type="submit">Enviar</button>

          </form>

        </div>

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>
    </>
  )
}

export default Senha;