import './style.css'
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

import Perfil from '../../assets/perfil.png'

function VisualizarHorarios() {

  const navigate = useNavigate();

  const [reservas, setReservas] = useState([]);
  const [loading, setLoading] = useState(true);

  // LOGIN
  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  // =========================
  // BUSCAR RESERVAS
  // =========================
  async function buscarReservas() {

    if (!token) {

      navigate("/login");

      return;

    }

    try {

      setLoading(true);

      console.log("TOKEN:", token);

      const response = await axios.get(
        "http://localhost:3000/minhas-reservas",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      console.log(
        "RESERVAS:",
        response.data
      );

      setReservas(response.data);

    } catch (err) {

      console.error(
        "ERRO COMPLETO:",
        err
      );

      if (err.response) {

        console.error(
          "ERRO API:",
          err.response.data
        );

        console.error(
          "STATUS:",
          err.response.status
        );

      }

      alert(
        "Erro ao carregar reservas"
      );

    } finally {

      setLoading(false);

    }

  }

  // =========================
  // CANCELAR RESERVA
  // =========================
  async function cancelarReserva(id, e) {

    // EVITA ABRIR A PARTIDA
    e.stopPropagation();

    const confirmar = window.confirm(
      "Deseja cancelar esta reserva?"
    );

    if (!confirmar) return;

    try {

      await axios.delete(
        `http://localhost:3000/cancelar-reserva/${id}`,
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      alert(
        "Reserva cancelada!"
      );

      buscarReservas();

    } catch (err) {

      console.error(
        "ERRO AO CANCELAR:",
        err
      );

      alert(
        "Erro ao cancelar reserva"
      );

    }

  }

  // =========================
  // ABRIR PARTIDA
  // =========================
  function abrirPartida(id) {

    navigate(`/partida/${id}`);

  }

  // =========================
  // VERIFICAR SE PODE CANCELAR
  // =========================
  function podeCancelar(dataReserva, horario) {

    try {

      const agora = new Date();

      const data =
        new Date(dataReserva);

      const ano =
        data.getFullYear();

      const mes =
        String(
          data.getMonth() + 1
        ).padStart(2, "0");

      const dia =
        String(
          data.getDate()
        ).padStart(2, "0");

      // REMOVE SEGUNDOS
      const horaFormatada =
        horario.length === 5
          ? horario
          : horario.slice(0, 5);

      const dataHoraReserva =
        new Date(
          `${ano}-${mes}-${dia}T${horaFormatada}:00`
        );

      return dataHoraReserva > agora;

    } catch (err) {

      console.error(err);

      return false;

    }

  }

  // =========================
  // FORMATAR DATA
  // =========================
  function formatarData(data) {

    try {

      return new Date(data)
        .toLocaleDateString("pt-BR");

    } catch {

      return data;

    }

  }

  // =========================
  // FORMATAR HORA
  // =========================
  function formatarHora(hora) {

    if (!hora) return "";

    return hora.slice(0, 5);

  }

  useEffect(() => {

    buscarReservas();

  }, []);

  return(

    <>

      
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>
      
      {/* CONTEÚDO */}
      <div className="reservas-page">

        {/* HERO */}
        <div className="reservas-hero">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

          <h1>
            Minhas Partidas
          </h1>

          <p>
            Clique em uma partida
            para visualizar detalhes,
            convidar amigos e gerenciar
            participantes.
          </p>

        </div>

        {/* LISTA */}
        <div className="reservas-container">

          {loading && (

            <div className="sem-reserva">
              Carregando partidas...
            </div>

          )}

          {!loading &&
            reservas.length === 0 && (

            <div className="sem-reserva">

              <h2>
                Nenhuma partida encontrada
              </h2>

              <p>
                Você ainda não realizou
                nenhum agendamento.
              </p>

            </div>

          )}

          <div className="reservas-grid">

            {reservas.map((reserva) => (

              <div
                className="card-reserva"
                key={
                  reserva.ID_AGENDAMENTO
                }
                onClick={() =>
                  abrirPartida(
                    reserva.ID_AGENDAMENTO
                  )
                }
              >

                {/* TOPO */}
                <div className="card-topo">

                  <span className="quadra-badge">
                    Quadra {
                      reserva.ID_QUADRA
                    }
                  </span>

                  <span
                    className={
                      podeCancelar(
                        reserva.DT_AGENDAMENTO,
                        reserva.HR_AGENDAMENTO
                      )
                        ? "status-agendada"
                        : "status-finalizada"
                    }
                  >
                    {podeCancelar(
                      reserva.DT_AGENDAMENTO,
                      reserva.HR_AGENDAMENTO
                    )
                      ? "Agendada"
                      : "Finalizada"}
                  </span>

                </div>

                {/* INFO */}
                <div className="info-reserva">

                  <div className="info-item">

                    <span className="info-label">
                      Data
                    </span>

                    <span className="info-value">
                      {formatarData(
                        reserva.DT_AGENDAMENTO
                      )}
                    </span>

                  </div>

                  <div className="info-item">

                    <span className="info-label">
                      Horário
                    </span>

                    <span className="info-value">
                      {formatarHora(
                        reserva.HR_AGENDAMENTO
                      )}
                    </span>

                  </div>

                </div>

                {/* FOOTER */}
                <div className="card-footer">

                  <span className="abrir-partida">

                    Clique para abrir
                    a partida →

                  </span>

                </div>

                {/* BOTÃO CANCELAR */}
                {podeCancelar(
                  reserva.DT_AGENDAMENTO,
                  reserva.HR_AGENDAMENTO
                ) && (

                  <button
                    className="btn-cancelar"
                    onClick={(e) =>
                      cancelarReserva(
                        reserva.ID_AGENDAMENTO,
                        e
                      )
                    }
                  >
                    Cancelar Reserva
                  </button>

                )}

              </div>

            ))}

          </div>

        </div>

      </div>



      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>
    </>

  )

}

export default VisualizarHorarios;