import './style.css'

import {
  Link,
  useNavigate,
  useParams
} from "react-router-dom";

import {
  useEffect,
  useState
} from "react";

import axios from "axios";

import Perfil from '../../assets/perfil.png'

function Partida() {

  const navigate = useNavigate();

  const { id } = useParams();

  // LOGIN
  const token =
    localStorage.getItem("token");

  const user =
    localStorage.getItem("user");

  const nome =
    localStorage.getItem("nome");

  // STATES
  const [partida, setPartida] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  const [emailConvite, setEmailConvite] =
    useState("");

  const [esporte, setEsporte] =
    useState("");

  const [partidaAberta, setPartidaAberta] =
    useState(false);

  const [participantes, setParticipantes] =
    useState([]);

  const [souParticipante, setSouParticipante] =
    useState(false);

  // =========================
  // PERFIL
  // =========================

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  // =========================
  // BUSCAR PARTIDA
  // =========================

  async function buscarPartida() {

    try {

      setLoading(true);

      const response =
        await axios.get(
          `http://localhost:3000/partida/${id}`,
          {
            headers: {
              Authorization:
                `Bearer ${token}`
            }
          }
        );

      console.log(
        "PARTIDA:",
        response.data
      );

      setPartida(response.data);

      setEsporte(
        response.data.esporte || ""
      );

      setPartidaAberta(
        response.data.aberta === 1
      );

      setParticipantes(
        response.data.participantes || []
      );

      const participanteExiste =
        response.data.participantes?.some(
          (p) =>
            Number(p.id_usuario) ===
            Number(token)
        );

      setSouParticipante(
        participanteExiste || false
      );

    } catch (err) {

      console.error(err);

      alert(
        "Erro ao carregar partida"
      );

    } finally {

      setLoading(false);

    }

  }

  // =========================
  // ENTRAR PARTIDA
  // =========================

  async function entrarNaPartida() {

    try {

      await axios.post(
        "http://localhost:3000/partida/participar",
        {
          id_agendamento: id
        },
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      alert(
        "Você entrou na partida!"
      );

      buscarPartida();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao entrar na partida"
      );

    }

  }

  // =========================
  // ENVIAR CONVITE
  // =========================

  async function enviarConvite() {

    if (!emailConvite) {

      alert(
        "Digite um e-mail"
      );

      return;

    }

    try {

      await axios.post(
        "http://localhost:3000/convidar",
        {
          id_agendamento: id,
          email: emailConvite
        },
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      alert(
        "Convite enviado!"
      );

      setEmailConvite("");

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao enviar convite"
      );

    }

  }

  // =========================
  // SALVAR CONFIGURAÇÕES
  // =========================

  async function salvarConfiguracoes() {

    try {

      await axios.put(
        `http://localhost:3000/partida/${id}`,
        {
          esporte,
          partida_aberta:
            partidaAberta ? 1 : 0
        },
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      alert(
        "Partida atualizada!"
      );

      buscarPartida();

    } catch (err) {

      console.error(err);

      alert(
        "Erro ao salvar"
      );

    }

  }

  // =========================
  // FORMATAR DATA
  // =========================

  function formatarData(data) {

    if (!data) return "";

    return new Date(data)
      .toLocaleDateString("pt-BR");

  }

  // =========================
  // FORMATAR HORA
  // =========================

  function formatarHora(hora) {

    if (!hora) return "Não definido";

    return String(hora)
      .trim()
      .slice(0, 5);

  }

  useEffect(() => {

    buscarPartida();

  }, []);

  return(

    <>

     {/* HEADER */}

     <div className="header">

{/* ESQUERDA */}

<div className="header-left">

  <Link
    to="/"
    className="logo-area"
  >

    <span className="logo1">
      Fatec Sorocaba
    </span>

    <span className="logo-sub">
      José Crespo Gonzales
    </span>

  </Link>

</div>

{/* CENTRO */}

<div className="header-center">

  <Link to="/">
    Home
  </Link>

  <Link to="/reservar-horario">
    Reservar Horários
  </Link>

  <Link to="/visualizar-horario">
    Horários Agendados
  </Link>

  <Link to="/reportar-atividades">
    Reportar Atividades
  </Link>

</div>

{/* DIREITA */}

<div className="header-right">

  <img
    src={Perfil}
    alt="perfil"
  />

  <span
    onClick={handleUserClick}
    style={{ cursor: "pointer" }}
  >

    {
      token
        ? user?.split("@")[0]
        : "Login"
    }

  </span>

</div>

</div>

      {/* CONTEÚDO */}

      <div className="partida-page">

        <button
          className="btn-voltar"
          onClick={() =>
            navigate(-1)
          }
        >
          ← Voltar
        </button>

        {loading && (

          <div className="loading">
            Carregando partida...
          </div>

        )}

        {!loading && partida && (

          <div className="partida-card">

            {/* TOPO */}

            <div className="partida-topo">

              <div>

                <span className="quadra-badge">
                  Quadra {partida.id_quadra}
                </span>

                <h1>
                  Partida Esportiva
                </h1>

              </div>

            </div>

            {/* INFORMAÇÕES */}

            <div className="partida-info">

              <div className="info-box">

                <span className="info-label">
                  DATA
                </span>

                <span className="info-value">
                  {formatarData(
                    partida.data
                  )}
                </span>

              </div>

              <div className="info-box">

                <span className="info-label">
                  HORÁRIO
                </span>

                <span className="info-value">
                  {formatarHora(
                    partida.horario
                  )}
                </span>

              </div>

            </div>

            {/* ENTRAR NA PARTIDA */}

            {partidaAberta &&
             !souParticipante && (

              <button
                className="btn-entrar"
                onClick={
                  entrarNaPartida
                }
              >
                Entrar na Partida
              </button>

            )}

            {/* ESPORTE */}

            <div className="config-section">

              <h2>
                Esporte da Partida
              </h2>

              <select
                value={esporte}
                onChange={(e) =>
                  setEsporte(
                    e.target.value
                  )
                }
              >

                <option value="">
                  Selecione
                </option>

                <option value="Futsal">
                  Futsal
                </option>

                <option value="Basquete">
                  Basquete
                </option>

                <option value="Vôlei">
                  Vôlei
                </option>

                <option value="Handebol">
                  Handebol
                </option>

                <option value="Tênis">
                  Tênis
                </option>

              </select>

            </div>

            {/* PARTIDA ABERTA */}

            <div className="config-section">

              <div className="checkbox-area">

                <input
                  type="checkbox"
                  checked={partidaAberta}
                  onChange={() =>
                    setPartidaAberta(
                      !partidaAberta
                    )
                  }
                />

                <span>
                  Permitir entrada
                  de jogadores interessados
                  no esporte
                </span>

              </div>

            </div>

            {/* PARTICIPANTES */}

            <div className="config-section">

              <h2>
                Participantes
              </h2>

              <div className="participantes-list">

                {participantes.length === 0 && (

                  <p className="sem-participantes">
                    Nenhum participante
                  </p>

                )}

                {participantes.map(
                  (p, index) => (

                  <div
                    key={index}
                    className="participante-item"
                  >

                    <div className="participante-avatar">
                      {p.nome?.charAt(0)}
                    </div>

                    <div>
                      <strong>
                        {p.nome}
                      </strong>
                    </div>

                  </div>

                ))}

              </div>

            </div>

            {/* CONVIDAR */}

            <div className="config-section">

              <h2>
                Convidar Amigos
              </h2>

              <div className="convite-area">

                <input
                  type="email"
                  placeholder="Digite o e-mail institucional"
                  value={emailConvite}
                  onChange={(e) =>
                    setEmailConvite(
                      e.target.value
                    )
                  }
                />

                <button
                  className="btn-convite"
                  onClick={enviarConvite}
                >
                  Enviar Convite
                </button>

              </div>

            </div>

            {/* BOTÃO */}

            <button
              className="btn-salvar"
              onClick={
                salvarConfiguracoes
              }
            >
              Salvar Configurações
            </button>

          </div>

        )}

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>

    </>

  )

}

export default Partida;