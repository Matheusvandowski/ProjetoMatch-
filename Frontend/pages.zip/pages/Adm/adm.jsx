import './style.css'
import PerfilImg from '../../assets/perfil.png'

import {
  FaUsers,
  FaBasketballBall,
  FaClipboardList,
  FaChartBar,
  FaArrowRight
} from "react-icons/fa";

import { Link, useNavigate } from "react-router-dom";

function Adm() {

  const navigate = useNavigate();

  const user = localStorage.getItem("user");

  return (
    <>
      {/* HEADER */}

      <div className="header">

        <div className="header-left">

          <Link to="/" className="logo1">
            Fatec Sorocaba
          </Link>

          <span className="logo-sub">
            José Crespo Gonzales
          </span>

        </div>

        <div className="header-center">

        <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horário
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        <div
          className="header-right"
          onClick={() => navigate("/perfil")}
        >

          <img
            src={PerfilImg}
            alt="perfil"
          />

          <span>
            {user}
          </span>

        </div>

      </div>

      

      {/* CONTAINER */}

      <div className="adm-container">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>


        {/* TITULO */}

        <div className="adm-top">

          <h1>
            Painel Administrativo
          </h1>

          <p>
            Gerencie usuários, quadras,
            reservas e estatísticas do sistema.
          </p>

        </div>

        {/* CARDS */}

        <div className="adm-grid">

          {/* USUÁRIOS */}

          <div
            className="adm-card"
            onClick={() => navigate("/gerenciarUsuarios")}
          >

            <div className="card-icon">
              <FaUsers />
            </div>

            <h2>
              Gerenciamento de Usuários
            </h2>

            <p>
              Cadastre, edite e controle
              permissões dos usuários.
            </p>

            <button>
              Acessar
              <FaArrowRight />
            </button>

          </div>

          {/* QUADRAS */}

          <div
            className="adm-card"
            onClick={() => navigate("/gerenciarQuadras")}
          >

            <div className="card-icon">
              <FaBasketballBall />
            </div>

            <h2>
              Gerenciamento de Quadras
            </h2>

            <p>
              Controle quadras, horários
              e disponibilidade.
            </p>

            <button>
              Acessar
              <FaArrowRight />
            </button>

          </div>

          {/* RESERVAS */}

          <div
            className="adm-card"
            onClick={() => navigate("/gerenciarReservas")}
          >

            <div className="card-icon">
              <FaClipboardList />
            </div>

            <h2>
              Gerenciamento de Reservas
            </h2>

            <p>
              Visualize e administre
              todas as reservas do sistema.
            </p>

            <button>
              Acessar
              <FaArrowRight />
            </button>

          </div>

          {/* ESTATÍSTICAS */}

          <div
            className="adm-card"
            onClick={() => navigate("/estatisticas")}
          >

            <div className="card-icon">
              <FaChartBar />
            </div>

            <h2>
              Estatísticas
            </h2>

            <p>
              Analise dados de uso,
              reservas e esportes.
            </p>

            <button>
              Acessar
              <FaArrowRight />
            </button>

          </div>

        </div>

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>
    </>
  )
}

export default Adm;