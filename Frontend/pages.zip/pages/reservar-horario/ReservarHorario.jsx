import './style.css'
import { Link, useNavigate } from "react-router-dom";

import Perfil from '../../assets/perfil.png'
import Quadra1 from '../../assets/quadra1.png'
import Quadra2 from '../../assets/quadra2.png'

function ReservarHorario() {

  const navigate = useNavigate();

  // LOGIN
  const token =
    localStorage.getItem("token");

  const user =
    localStorage.getItem("user");

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  return (

    <>

    {/* HEADER */}

    <div className="header">

{/* ESQUERDA */}

<div className="header-left">

  <Link
    to="/"
    className="logo-area"
  >

    <span className="logo1">
      Fatec Sorocaba
    </span>

    <span className="logo-sub">
      José Crespo Gonzales
    </span>

  </Link>

</div>

{/* CENTRO */}

<div className="header-center">

  <Link to="/">
    Home
  </Link>

  <Link to="/reservar-horario">
    Reservar Horários
  </Link>

  <Link to="/visualizar-horario">
    Horários Agendados
  </Link>

  <Link to="/reportar-atividades">
    Reportar Atividades
  </Link>

</div>

{/* DIREITA */}

<div className="header-right">

  <img
    src={Perfil}
    alt="perfil"
  />

  <span
    onClick={handleUserClick}
    style={{ cursor: "pointer" }}
  >

    {
      token
        ? user?.split("@")[0]
        : "Login"
    }

  </span>

</div>

</div>
      {/* =========================
          CONTEÚDO
      ========================== */}

      <main className="reserva-page">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>

        {/* TÍTULO */}

        <div className="titulo-area">

          <span className="titulo-badge">
            Escolha uma quadra
          </span>

          <h1>
            Reservar Horário
          </h1>

          <p>
            Selecione a quadra desejada
            para visualizar os horários
            disponíveis e realizar sua
            reserva.
          </p>

        </div>

        {/* CARDS */}

        <div className="quadras-container">

          {/* =========================
              QUADRA 1
          ========================== */}

          <div
            className="quadra-box"
            onClick={() =>
              navigate("/calendario")
            }
          >

            <div className="quadra-image-wrapper">

              <img
                src={Quadra1}
                alt="quadra1"
              />

              <div className="quadra-overlay">
                Disponível
              </div>

            </div>

            <div className="quadra-content">

              <h2>
                Quadra 1
              </h2>

              <p>
                Quadra poliesportiva
                ideal para futsal,
                vôlei e treinos.
              </p>

              <button
                className="btn-reservar"
              >
                Reservar Agora
              </button>

            </div>

          </div>

          {/* =========================
              QUADRA 2
          ========================== */}

          <div
            className="quadra-box"
            onClick={() =>
              navigate("/calendario2")
            }
          >

            <div className="quadra-image-wrapper">

              <img
                src={Quadra2}
                alt="quadra2"
              />

              <div className="quadra-overlay">
                Disponível
              </div>

            </div>

            <div className="quadra-content">

              <h2>
                Quadra 2
              </h2>

              <p>
                Espaço moderno para
                partidas, treinos e
                atividades esportivas.
              </p>

              <button
                className="btn-reservar"
              >
                Reservar Agora
              </button>

            </div>

          </div>

        </div>

      </main>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone:
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento:
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              <i className="fab fa-facebook-f"></i>
            </a>

            <a href="#">
              <i className="fab fa-instagram"></i>
            </a>

            <a href="#">
              <i className="fab fa-linkedin-in"></i>
            </a>

            <a href="#">
              <i className="fab fa-youtube"></i>
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>
      
    </>

  );

}

export default ReservarHorario;