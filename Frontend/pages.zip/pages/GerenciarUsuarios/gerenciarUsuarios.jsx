import './style.css'
import PerfilImg from '../../assets/perfil.png'

import {
  FaUsers,
  FaSearch,
  FaUserShield,
  FaUser,
  FaCrown,
  FaUserSlash,
  FaArrowUp
} from "react-icons/fa";

import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";

function GerenciarUsuarios() {

  const navigate = useNavigate();

  const user = localStorage.getItem("user");
  const meuTipo = Number(localStorage.getItem("tipo"));
  const meuId = Number(localStorage.getItem("token"));
  const token = localStorage.getItem("token");

  const [usuarios, setUsuarios] = useState([]);
  const [usuariosFiltrados, setUsuariosFiltrados] = useState([]);

  const [filtro, setFiltro] = useState("nome");
  const [pesquisa, setPesquisa] = useState("");

  /* ================================
     CLICK USER
  ================================= */

  function handleUserClick() {

    if (token) {

      navigate("/perfil");
      return;

    }

    navigate("/login");
  }

  /* ================================
     BUSCAR USUÁRIOS
  ================================= */

  async function carregarUsuarios() {

    try {

      const response = await axios.get(
        "http://localhost:3000/usuarios"
      );

      setUsuarios(response.data);
      setUsuariosFiltrados(response.data);

    } catch (err) {

      console.error(err);
      alert("Erro ao carregar usuários");

    }
  }

  useEffect(() => {

    carregarUsuarios();

  }, []);

  /* ================================
     FILTRAR
  ================================= */

  useEffect(() => {

    const filtrados = usuarios.filter((usuario) => {

      const valor =
        usuario[filtro]
          ?.toString()
          .toLowerCase();

      return valor?.includes(
        pesquisa.toLowerCase()
      );

    });

    setUsuariosFiltrados(filtrados);

  }, [pesquisa, filtro, usuarios]);

  /* ================================
     BADGE TIPO
  ================================= */

  function tipoUsuario(tipo) {

    if (tipo == 2) {

      return (
        <span className="tipo master">
          <FaCrown />
          ADM MASTER
        </span>
      )
    }

    if (tipo == 1) {

      return (
        <span className="tipo adm">
          <FaUserShield />
          ADM
        </span>
      )
    }

    return (
      <span className="tipo comum">
        <FaUser />
        COMUM
      </span>
    )
  }

  /* ================================
     PROMOVER
  ================================= */

  async function promoverUsuario(id) {

    try {

      await axios.put(
        `http://localhost:3000/usuarios/promover/${id}`,
        {
          meuTipo,
          meuId
        }
      );

      carregarUsuarios();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao promover usuário"
      );

    }
  }

  /* ================================
     DESPROMOVER
  ================================= */

  async function despromoverUsuario(id) {

    try {

      await axios.put(
        `http://localhost:3000/usuarios/despromover/${id}`,
        {
          meuTipo,
          meuId
        }
      );

      carregarUsuarios();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao despromover usuário"
      );

    }
  }

  /* ================================
     INATIVAR
  ================================= */

  async function inativarUsuario(id) {

    try {

      await axios.put(
        `http://localhost:3000/usuarios/inativar/${id}`,
        {
          meuTipo,
          meuId
        }
      );

      carregarUsuarios();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao inativar usuário"
      );

    }
  }

  /* ================================
     ATIVAR
  ================================= */

  async function ativarUsuario(id) {

    try {

      await axios.put(
        `http://localhost:3000/usuarios/ativar/${id}`,
        {
          meuTipo,
          meuId
        }
      );

      carregarUsuarios();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao ativar usuário"
      );

    }
  }

  /* ================================
     REGRAS
  ================================= */

  function podeInativar(usuario) {

    // MASTER
    if (
      meuTipo === 2 &&
      usuario.id !== meuId
    ) {

      return true;

    }

    // ADM COMUM
    if (
      meuTipo === 1 &&
      usuario.tipo === 0 &&
      usuario.id !== meuId
    ) {

      return true;

    }

    return false;
  }

  return (
    <>
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={PerfilImg}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTAINER */}

      <div className="usuarios-container">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>

        {/* TOPO */}

        <div className="usuarios-top">

          <div>

            <h1>
              <FaUsers />
              Gerenciamento de Usuários
            </h1>

            <p>
              Gerencie permissões e usuários do sistema.
            </p>

          </div>

        </div>

        {/* FILTROS */}

        <div className="filtros">

          <div className="filtro-select">

            <select
              value={filtro}
              onChange={(e) =>
                setFiltro(e.target.value)
              }
            >

              <option value="nome">
                Nome
              </option>

              <option value="ra">
                RA
              </option>

              <option value="email">
                E-mail
              </option>

            </select>

          </div>

          <div className="pesquisa-box">

            <FaSearch />

            <input
              type="text"
              placeholder="Pesquisar usuário..."
              value={pesquisa}
              onChange={(e) =>
                setPesquisa(e.target.value)
              }
            />

          </div>

        </div>

        {/* TABELA */}

        <div className="usuarios-table">

          <div className="table-header">

            <span>Nome</span>
            <span>RA</span>
            <span>Status</span>
            <span>Ativo</span>
            <span>E-mail</span>

          </div>

          {
            usuariosFiltrados.map((usuario) => (

              <div
                className="table-row"
                key={usuario.id}
              >

                {/* NOME + AÇÕES */}

                <div className="nome-box">

                  <span className="nome-user">
                    {usuario.nome}
                  </span>

                  <div className="acoes-inline">

                    {
                      meuTipo === 2 &&
                      usuario.tipo === 0 &&
                      usuario.id !== meuId && (

                        <button
                          className="btn-mini promover"
                          onClick={() =>
                            promoverUsuario(usuario.id)
                          }
                        >

                          <FaArrowUp />

                        </button>
                      )
                    }

                    {
                      meuTipo === 2 &&
                      usuario.tipo === 1 &&
                      usuario.id !== meuId && (

                        <button
                          className="btn-mini despromover"
                          onClick={() =>
                            despromoverUsuario(usuario.id)
                          }
                        >

                          <FaArrowUp />

                        </button>
                      )
                    }

                    {
                      podeInativar(usuario) &&
                      usuario.ativo == 1 && (

                        <button
                          className="btn-mini inativar"
                          onClick={() =>
                            inativarUsuario(usuario.id)
                          }
                        >

                          <FaUserSlash />

                        </button>
                      )
                    }

                    {
                      podeInativar(usuario) &&
                      usuario.ativo == 0 && (

                        <button
                          className="btn-mini ativar"
                          onClick={() =>
                            ativarUsuario(usuario.id)
                          }
                        >

                          <FaUser />

                        </button>
                      )
                    }

                  </div>

                </div>

                {/* RA */}

                <span>
                  {usuario.ra}
                </span>

                {/* STATUS */}

                <span>
                  {tipoUsuario(usuario.tipo)}
                </span>

                {/* ATIVO */}

                <span>

                  {
                    usuario.ativo == 1
                      ? (
                        <div className="ativo">
                          ATIVO
                        </div>
                      )
                      : (
                        <div className="inativo">
                          INATIVO
                        </div>
                      )
                  }

                </span>

                {/* EMAIL */}

                <span>
                  {usuario.email}
                </span>

              </div>

            ))
          }

        </div>

      </div>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              F
            </a>

            <a href="#">
              Insta
            </a>

            <a href="#">
              LkdIn
            </a>

            <a href="#">
              YT
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>
    </>
  );
}

export default GerenciarUsuarios;