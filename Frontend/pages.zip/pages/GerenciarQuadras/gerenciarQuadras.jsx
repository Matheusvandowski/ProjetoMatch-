import './style.css'

import PerfilImg from '../../assets/perfil.png'

import {
  FaFutbol,
  FaPlus,
  FaEdit,
  FaPowerOff,
  FaSearch,
  FaMapMarkerAlt,
  FaImage,
  FaCheck,
  FaTrash
} from "react-icons/fa";

import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

import axios from "axios";

function GerenciarQuadras() {

  const navigate = useNavigate();

  const user = localStorage.getItem("user");

  const tipo = localStorage.getItem("tipo");

  const token = localStorage.getItem("token");

  const [quadras, setQuadras] = useState([]);

  const [pesquisa, setPesquisa] = useState("");

  const [nomeQuadra, setNomeQuadra] = useState("");

  const [localizacaoQuadra, setLocalizacaoQuadra] =
    useState("");

  const [fotoQuadra, setFotoQuadra] =
    useState(null);

  // ================================
  // USER CLICK
  // ================================

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  // ================================
  // PROTEGER ROTA
  // ================================

  useEffect(() => {

    if (tipo != 1 && tipo != 2) {

      navigate("/");

    }

    carregarQuadras();

  }, []);

  // ================================
  // BUSCAR QUADRAS
  // ================================

  async function carregarQuadras() {

    try {

      const response = await axios.get(
        "http://localhost:3000/quadras"
      );

      setQuadras(response.data);

    } catch (err) {

      console.error(err);

      alert("Erro ao carregar quadras");

    }
  }

  // ================================
  // PEGAR IMAGEM
  // ================================

  function converterImagem(e) {

    const file = e.target.files[0];

    if (!file) return;

    setFotoQuadra(file);

  }

  // ================================
  // ADICIONAR QUADRA
  // ================================

  async function adicionarQuadra() {

    if (
      !nomeQuadra ||
      !localizacaoQuadra
    ) {

      alert("Preencha todos os campos");

      return;

    }

    try {

      const formData = new FormData();

      formData.append(
        "nome",
        nomeQuadra
      );

      formData.append(
        "localizacao",
        localizacaoQuadra
      );

      if (fotoQuadra) {

        formData.append(
          "foto",
          fotoQuadra
        );

      }

      await axios.post(
        "http://localhost:3000/quadras",
        formData,
        {
          headers: {
            "Content-Type":
              "multipart/form-data"
          }
        }
      );

      alert("Quadra adicionada!");

      setNomeQuadra("");
      setLocalizacaoQuadra("");
      setFotoQuadra(null);

      carregarQuadras();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao adicionar quadra"
      );

    }
  }

  // ================================
  // EDITAR QUADRA
  // ================================

  async function editarQuadra(quadra) {

    const novoNome = prompt(
      "Novo nome da quadra:",
      quadra.nome
    );

    if (!novoNome) return;

    const novaLocalizacao = prompt(
      "Nova localização:",
      quadra.localizacao
    );

    if (!novaLocalizacao) return;

    const input =
      document.createElement("input");

    input.type = "file";
    input.accept = "image/*";

    input.onchange = async (e) => {

      const arquivo = e.target.files[0];

      try {

        const formData = new FormData();

        formData.append(
          "nome",
          novoNome
        );

        formData.append(
          "localizacao",
          novaLocalizacao
        );

        if (arquivo) {

          formData.append(
            "foto",
            arquivo
          );

        }

        await axios.put(
          `http://localhost:3000/quadras/${quadra.id}`,
          formData,
          {
            headers: {
              "Content-Type":
                "multipart/form-data"
            }
          }
        );

        alert("Quadra atualizada!");

        carregarQuadras();

      } catch (err) {

        console.error(err);

        alert(
          err.response?.data ||
          "Erro ao atualizar quadra"
        );

      }

    };

    input.click();
  }

  // ================================
  // INATIVAR
  // ================================

  async function inativarQuadra(id) {

    try {

      await axios.put(
        `http://localhost:3000/quadras/inativar/${id}`
      );

      alert("Quadra inativada!");

      carregarQuadras();

    } catch (err) {

      console.error(err);

      alert("Erro ao inativar quadra");

    }
  }

  // ================================
  // ATIVAR
  // ================================

  async function ativarQuadra(id) {

    try {

      await axios.put(
        `http://localhost:3000/quadras/ativar/${id}`
      );

      alert("Quadra ativada!");

      carregarQuadras();

    } catch (err) {

      console.error(err);

      alert("Erro ao ativar quadra");

    }
  }

  // ================================
  // EXCLUIR QUADRA
  // ================================

  async function excluirQuadra(id) {

    const confirmar = window.confirm(
      "Deseja excluir esta quadra permanentemente?"
    );

    if (!confirmar) return;

    try {

      await axios.delete(
        `http://localhost:3000/quadras/${id}`
      );

      alert("Quadra excluída!");

      carregarQuadras();

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao excluir quadra"
      );

    }

  }

  // ================================
  // FILTRAR
  // ================================

  const quadrasFiltradas = quadras.filter((q) =>
    q.nome
      .toLowerCase()
      .includes(
        pesquisa.toLowerCase()
      )
  );

  return (
    <div className="page-container">

      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={PerfilImg}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTAINER */}

      <div className="quadras-container">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>

        {/* TOPO */}

        <div className="quadras-top">

          <h1>

            <FaFutbol />

            Gerenciamento de Quadras

          </h1>

          <p>
            Gerencie todas as quadras do sistema
          </p>

        </div>

        {/* ÁREA PRINCIPAL */}

        <div className="quadras-area">

          {/* ESQUERDA */}

          <div className="nova-quadra">

            <h2>
              Nova Quadra
            </h2>

            <input
              type="text"
              placeholder="Nome da quadra"
              value={nomeQuadra}
              onChange={(e) =>
                setNomeQuadra(e.target.value)
              }
            />

            <input
              type="text"
              placeholder="Localização da quadra"
              value={localizacaoQuadra}
              onChange={(e) =>
                setLocalizacaoQuadra(
                  e.target.value
                )
              }
            />

            <label className="upload-foto">

              <FaImage />

              {
                fotoQuadra
                  ? fotoQuadra.name
                  : "Selecionar Foto"
              }

              <input
                type="file"
                accept="image/*"
                onChange={converterImagem}
                hidden
              />

            </label>

            <button onClick={adicionarQuadra}>

              <FaPlus />

              Adicionar

            </button>

          </div>

          {/* DIREITA */}

          <div className="quadras-right">

            {/* PESQUISA */}

            <div className="pesquisa-box">

              <FaSearch />

              <input
                type="text"
                placeholder="Pesquisar quadra..."
                value={pesquisa}
                onChange={(e) =>
                  setPesquisa(e.target.value)
                }
              />

            </div>

            {/* LISTA */}

            <div className="quadras-lista">

              {
                quadrasFiltradas.map((quadra) => (

                  <div
                    className="quadra-card"
                    key={quadra.id}
                  >

                    {/* FOTO */}

                    <div className="quadra-imagem">

                      <img
                        src={
                          quadra.foto
                            ? quadra.foto
                            : "https://via.placeholder.com/400x200"
                        }
                        alt={quadra.nome}
                      />

                    </div>

                    {/* INFO */}

                    <div className="quadra-info">

                      <h3>
                        {quadra.nome}
                      </h3>

                      <p>

                        <FaMapMarkerAlt />

                        {" "}

                        {quadra.localizacao}

                      </p>

                      <span
                        className={
                          quadra.disponibilidade == 1
                            ? "status ativo"
                            : "status inativo"
                        }
                      >

                        {
                          quadra.disponibilidade == 1
                            ? "ATIVA"
                            : "INATIVA"
                        }

                      </span>

                      {/* AÇÕES */}

                      <div className="acoes">

                        <button
                          className="editar"
                          onClick={() =>
                            editarQuadra(
                              quadra
                            )
                          }
                        >

                          <FaEdit />

                        </button>

                        {
                          quadra.disponibilidade == 1
                          ? (

                            <button
                              className="inativar"
                              onClick={() =>
                                inativarQuadra(
                                  quadra.id
                                )
                              }
                            >

                              <FaPowerOff />

                            </button>

                          ) : (

                            <button
                              className="ativar"
                              onClick={() =>
                                ativarQuadra(
                                  quadra.id
                                )
                              }
                            >

                              <FaCheck />

                            </button>

                          )
                        }

                        <button
                          className="excluir"
                          onClick={() =>
                            excluirQuadra(
                              quadra.id
                            )
                          }
                        >

                          <FaTrash />

                        </button>

                      </div>

                    </div>

                  </div>

                ))
              }

            </div>

          </div>

        </div>

      </div>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              F
            </a>

            <a href="#">
              Insta
            </a>

            <a href="#">
              LkdIn
            </a>

            <a href="#">
              YT
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>

    </div>
  );
}

export default GerenciarQuadras;