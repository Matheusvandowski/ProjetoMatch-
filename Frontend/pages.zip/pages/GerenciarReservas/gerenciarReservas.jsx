import "./style.css";

import { useEffect, useState } from "react";

import { Link, useNavigate } from "react-router-dom";

import Perfil from "../../assets/perfil.png";

function GerenciarReservas() {

  const [reservas, setReservas] = useState([]);

  const [loading, setLoading] = useState(true);

  /* =================================
     MANUTENÇÃO
  ================================= */

  const [quadras, setQuadras] = useState([]);

  const [idQuadra, setIdQuadra] = useState("");

  const [dataInicio, setDataInicio] = useState("");

  const [dataFim, setDataFim] = useState("");

  const [motivo, setMotivo] = useState("");

  const navigate = useNavigate();

  const token = localStorage.getItem("token");

  const user = localStorage.getItem("user");

  /* =================================
     USER CLICK
  ================================= */

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  /* =================================
     BUSCAR RESERVAS
  ================================= */

  async function buscarReservas() {

    try {

      const response = await fetch(
        "http://localhost:3000/todas-reservas"
      );

      const data = await response.json();

      setReservas(data);

    } catch (err) {

      console.error(err);

      alert("Erro ao buscar reservas");

    } finally {

      setLoading(false);

    }

  }

  /* =================================
     BUSCAR QUADRAS
  ================================= */

  async function buscarQuadras() {

    try {

      const response =
        await fetch(
          "http://localhost:3000/quadras"
        );

      const data =
        await response.json();

      setQuadras(data);

    } catch (err) {

      console.error(err);

    }

  }

  /* =================================
     APLICAR MANUTENÇÃO
  ================================= */

  async function aplicarManutencao() {

    if (
      !idQuadra ||
      !dataInicio ||
      !dataFim ||
      !motivo
    ) {

      return alert(
        "Preencha todos os campos"
      );

    }

    try {

      const response =
        await fetch(
          "http://localhost:3000/manutencao",
          {

            method: "POST",

            headers: {
              "Content-Type":
                "application/json"
            },

            body: JSON.stringify({

              id_quadra: idQuadra,

              data_inicio: dataInicio,

              data_fim: dataFim,

              motivo

            })

          }
        );

      const mensagem =
        await response.text();

      if (!response.ok) {

        return alert(mensagem);

      }

      alert(mensagem);

      setIdQuadra("");
      setDataInicio("");
      setDataFim("");
      setMotivo("");

      buscarReservas();

    } catch (err) {

      console.error(err);

      alert(
        "Erro ao aplicar manutenção"
      );

    }

  }

  /* =================================
     CANCELAR RESERVA
  ================================= */

  async function cancelarReserva(id) {

    const confirmar =
      window.confirm(
        "Deseja cancelar esta reserva?"
      );

    if (!confirmar) return;

    try {

      const response = await fetch(
        `http://localhost:3000/cancelar-reserva/${id}`,
        {
          method: "DELETE",

          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );

      const mensagem =
        await response.text();

      if (!response.ok) {

        return alert(mensagem);

      }

      alert(mensagem);

      buscarReservas();

    } catch (err) {

      console.error(err);

      alert("Erro ao cancelar reserva");

    }

  }

  /* =================================
     USE EFFECT
  ================================= */

  useEffect(() => {

    buscarReservas();

    buscarQuadras();

  }, []);

  /* =================================
     LOADING
  ================================= */

  if (loading) {

    return (

      <div className="container-gerenciar">

        <h2>Carregando reservas...</h2>

      </div>

    );

  }

  /* =================================
     JSX
  ================================= */

  return (

    <>
    
      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTEÚDO */}

      <div className="container-gerenciar">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>


        <div className="titulo-gerenciar">

          <h1>Gerenciar Reservas</h1>

          <p>
            Visualize e gerencie todas
            as reservas do sistema.
          </p>

        </div>

        {/* =================================
           BLOCO MANUTENÇÃO
        ================================= */}

        <div className="box-manutencao">

          <h2>Manutenção de Quadra</h2>

          <p>
            Defina um período de manutenção.
            Todas as reservas dentro desse prazo
            serão canceladas automaticamente.
          </p>

          <div className="form-manutencao">

            {/* QUADRA */}

            <select
              value={idQuadra}
              onChange={(e) =>
                setIdQuadra(e.target.value)
              }
            >

              <option value="">
                Selecione a quadra
              </option>

              {
                quadras.map((q) => (

                  <option
                    key={q.id}
                    value={q.id}
                  >
                    {q.nome}
                  </option>

                ))
              }

            </select>

            {/* DATA INÍCIO */}

            <input
              type="date"
              value={dataInicio}
              onChange={(e) =>
                setDataInicio(e.target.value)
              }
            />

            {/* DATA FIM */}

            <input
              type="date"
              value={dataFim}
              onChange={(e) =>
                setDataFim(e.target.value)
              }
            />

            {/* MOTIVO */}

            <input
              type="text"
              placeholder="Motivo da manutenção"
              value={motivo}
              onChange={(e) =>
                setMotivo(e.target.value)
              }
            />

            {/* BOTÃO */}

            <button
              className="btn-manutencao"
              onClick={aplicarManutencao}
            >
              Aplicar Manutenção
            </button>

          </div>

        </div>

        {/* TABELA */}

        {
          reservas.length === 0 ? (

            <p>
              Nenhuma reserva encontrada.
            </p>

          ) : (

            <table className="tabela-reservas">

              <thead>

                <tr>

                  <th>ID</th>

                  <th>Quadra</th>

                  <th>Usuário</th>

                  <th>Data</th>

                  <th>Horário</th>

                  <th>Ações</th>

                </tr>

              </thead>

              <tbody>

                {
                  reservas.map((reserva) => (

                    <tr key={reserva.id}>

                      <td>{reserva.id}</td>

                      <td>{reserva.quadra}</td>

                      <td>{reserva.usuario}</td>

                      <td>{reserva.data}</td>

                      <td>{reserva.horario}</td>

                      <td>

                        <button
                          className="btn-cancelar"
                          onClick={() =>
                            cancelarReserva(reserva.id)
                          }
                        >
                          Cancelar
                        </button>

                      </td>

                    </tr>

                  ))
                }

              </tbody>

            </table>

          )
        }

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>

    </>

  );

}

export default GerenciarReservas;