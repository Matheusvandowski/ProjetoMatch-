import './style.css'
import Perfil from '../../assets/perfil.png'

import { Link, useNavigate } from "react-router-dom";

import {
  useState,
  useMemo,
  useEffect
} from "react";

import Calendar from "react-calendar";

import Holidays from "date-holidays";

import axios from "axios";

function Calendario() {

  const navigate = useNavigate();

  const [data, setData] = useState(new Date());

  const [horarios, setHorarios] = useState([]);

  const [loading, setLoading] = useState(false);

  // QUADRA 1
  const [quadra] = useState(1);

  const hd = useMemo(
    () => new Holidays('BR'),
    []
  );

  /* ==============================
     LOGIN
  ============================== */

  const token =
    localStorage.getItem("token");

  const nome =
    localStorage.getItem("nome");

  const user =
    localStorage.getItem("user");

  /* ==============================
     PEGAR NOME USUÁRIO
  ============================== */

  function getNomeUsuario() {

    if (!token) {
      return "Login";
    }

    if (
      nome &&
      nome !== "null" &&
      nome !== "undefined"
    ) {

      return nome;

    }

    if (
      user &&
      user !== "null" &&
      user !== "undefined"
    ) {

      return user.split("@")[0];

    }

    return "Usuário";

  }

  /* ==============================
     USER CLICK
  ============================== */

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  /* ==============================
     FORMATAR DATA
  ============================== */

  function formatarData(date) {

    const ano =
      date.getFullYear();

    const mes =
      String(date.getMonth() + 1)
        .padStart(2, "0");

    const dia =
      String(date.getDate())
        .padStart(2, "0");

    return `${ano}-${mes}-${dia}`;

  }

  /* ==============================
     BUSCAR HORÁRIOS
  ============================== */

  async function buscarHorarios(date) {

    const dataFormatada =
      formatarData(date);

    setLoading(true);

    try {

      const res =
        await axios.get(
          `http://localhost:3000/agendamentos/${quadra}/${dataFormatada}`
        );

      const todosHorarios = [

        "08:00",
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "13:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
        "18:00",
        "19:00",
        "20:00",
        "21:00"

      ];

      const horariosFormatados =
        todosHorarios.map(
          (hora) => ({

            horario: hora,

            disponivel:
              !res.data.includes(hora)

          })
        );

      setHorarios(
        horariosFormatados
      );

    } catch (err) {

      console.error(
        "Erro ao buscar horários:",
        err
      );

      setHorarios([]);

    }

    setLoading(false);

  }

  /* ==============================
   RESERVAR
============================== */

async function reservar(horario) {

  if (!token) {

    alert("Faça login primeiro!");

    navigate("/login");

    return;

  }

  const confirmar = window.confirm(
    `Deseja confirmar a reserva da Quadra ${quadra} no horário ${horario}?`
  );

  if (!confirmar) {
    return;
  }

  try {

    const res = await axios.post(
      "http://localhost:3000/reservar",
      {

        id_quadra: quadra,

        dt_agendamento:
          formatarData(data),

        hr_agendamento:
          horario

      },
      {

        headers: {

          Authorization:
            `Bearer ${token}`

        }

      }
    );

    const idAgendamento =
      res.data.id_agendamento;

    alert(
      "Reserva realizada com sucesso!"
    );

    navigate(`/partida/${idAgendamento}`);

  } catch (err) {

    console.error(
      "ERRO RESERVA:",
      err
    );

    alert(
      err.response?.data ||
      "Erro ao reservar"
    );

  }

}
  /* ==============================
     USE EFFECT
  ============================== */

  useEffect(() => {

    buscarHorarios(data);

  }, []);

  /* ==============================
     JSX
  ============================== */

  return (

    <>

      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? getNomeUsuario()
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* CONTAINER */}

      <div className="container-calendario">

        <div className="card-calendario">

          {/* TOPO */}

          <div className="topo-calendario">

            <div>

              <span className="tag-quadra">
                Quadra {quadra}
              </span>

              <h1>
                Reservar Horário
              </h1>

              <p>
                Escolha um dia disponível
                e selecione o horário desejado.
              </p>

            </div>

            <button
              className="btn-voltar"
              onClick={() =>
                navigate(-1)
              }
            >
              ← Voltar
            </button>

          </div>

          {/* GRID */}

          <div className="grid-calendario">

            {/* CALENDÁRIO */}

            <div className="calendar-wrapper">

              <div className="calendar-topo">

                <h3>
                  Selecione a Data
                </h3>

                <span>
                  {
                    data.toLocaleDateString(
                      "pt-BR"
                    )
                  }
                </span>

              </div>

              <Calendar

                onChange={(value) => {

                  setData(value);

                  buscarHorarios(value);

                }}

                value={data}

                className="custom-calendar"

                tileClassName={({ date }) => {

                  const hoje =
                    new Date();

                  hoje.setHours(
                    0,0,0,0
                  );

                  const dia =
                    new Date(date);

                  dia.setHours(
                    0,0,0,0
                  );

                  const classes = [];

                  if (
                    dia.getDay() === 0
                  ) {

                    classes.push(
                      "domingo"
                    );

                  }

                  if (
                    hd.isHoliday(dia)
                  ) {

                    classes.push(
                      "feriado"
                    );

                  }

                  if (
                    dia < hoje
                  ) {

                    classes.push(
                      "passado"
                    );

                  }

                  return classes.join(" ");

                }}

              />

            </div>

            {/* HORÁRIOS */}

            <div className="box-horarios">

              <div className="topo-horarios">

                <div>

                  <h2>
                    Horários
                  </h2>

                  <p className="subtitulo-horarios">

                    {data.toLocaleDateString("pt-BR")}

                  </p>

                </div>

                <div className="legenda">

                  <div className="legenda-item">
                    <div className="legenda-cor disponivel"></div>
                    Disponível
                  </div>

                  <div className="legenda-item">
                    <div className="legenda-cor ocupado"></div>
                    Ocupado
                  </div>

                </div>

              </div>

              {

                loading && (
                  <p>Carregando horários...</p>
                )

              }

              {

                !loading &&
                horarios.length === 0 && (
                  <p>Nenhum horário disponível</p>
                )

              }

              <div className="lista-horarios">

                {

                  !loading &&

                  horarios.map((h, index) => (

                    <button

                      key={index}

                      className={
                        h.disponivel
                          ? "btn-horario"
                          : "btn-horario indisponivel"
                      }

                      disabled={!h.disponivel}

                      onClick={() =>
                        reservar(h.horario)
                      }

                    >

                      <span className="horario">
                        {h.horario}
                      </span>

                      <span className="status">

                        {
                          h.disponivel
                            ? "Clique para reservar"
                            : "Indisponível"
                        }

                      </span>

                    </button>

                  ))

                }

              </div>

            </div>

          </div>

        </div>

      </div>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              F
            </a>

            <a href="#">
              Insta
            </a>

            <a href="#">
              LkdIn
            </a>

            <a href="#">
              YT
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>

    </>

  );

}

export default Calendario;