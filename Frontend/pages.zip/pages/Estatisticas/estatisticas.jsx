import './style.css'

import {
  Link,
  useNavigate
} from "react-router-dom";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  CartesianGrid
} from "recharts";

import {
  useEffect,
  useState
} from "react";

import axios from "axios";

import Perfil from "../../assets/perfil.png";

function Estatisticas() {

  const navigate =
    useNavigate();

  const token =
    localStorage.getItem("token");

  const user =
    localStorage.getItem("user");

  const nome =
    localStorage.getItem("nome");

  // =========================
  // STATES
  // =========================

  const [
    horariosData,
    setHorariosData
  ] = useState([]);

  const [
    esportesData,
    setEsportesData
  ] = useState([]);

  const [
    mesesData,
    setMesesData
  ] = useState([]);

  const [
    usuariosData,
    setUsuariosData
  ] = useState([]);

  // =========================
  // PERFIL
  // =========================

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  // =========================
  // BUSCAR DADOS
  // =========================

  async function buscarDados() {

    try {

      const response =
        await axios.get(
          "http://localhost:3000/todas-reservas"
        );

      const reservas =
        response.data || [];

      console.log(
        "RESERVAS:",
        reservas
      );

      // =========================
      // HORÁRIOS
      // =========================

      const horariosMap = {};

      reservas.forEach(r => {

        const hora =
          r.horario || "00:00";

        horariosMap[hora] =
          (horariosMap[hora] || 0) + 1;

      });

      const horariosFormatados =
        Object.entries(horariosMap)
          .map(([hora, total]) => ({

            hora,
            total

          }))
          .sort((a, b) =>
            a.hora.localeCompare(b.hora)
          );

      setHorariosData(
        horariosFormatados
      );

      // =========================
      // ESPORTES
      // =========================

      const esportesMap = {};

      reservas.forEach(r => {

        const esporte =
          r.esporte || "Não definido";

        esportesMap[esporte] =
          (esportesMap[esporte] || 0) + 1;

      });

      const esportesFormatados =
        Object.entries(esportesMap)
          .map(([name, value]) => ({

            name,
            value

          }));

      setEsportesData(
        esportesFormatados
      );

      // =========================
      // MESES
      // =========================

      const nomesMeses = [
        "Jan",
        "Fev",
        "Mar",
        "Abr",
        "Mai",
        "Jun",
        "Jul",
        "Ago",
        "Set",
        "Out",
        "Nov",
        "Dez"
      ];

      const mesesMap = {};

      reservas.forEach(r => {

        if (!r.data) return;

        const data =
          new Date(r.data);

        const mes =
          nomesMeses[
            data.getMonth()
          ];

        mesesMap[mes] =
          (mesesMap[mes] || 0) + 1;

      });

      const mesesFormatados =
        nomesMeses.map(mes => ({

          mes,

          reservas:
            mesesMap[mes] || 0

        }));

      setMesesData(
        mesesFormatados
      );

      // =========================
      // USUÁRIOS
      // =========================

      const usuariosMap = {};

      reservas.forEach(r => {

        const usuario =
          r.usuario || "Usuário";

        usuariosMap[usuario] =
          (usuariosMap[usuario] || 0) + 1;

      });

      const usuariosFormatados =
        Object.entries(usuariosMap)
          .map(([nome, reservas]) => ({

            nome,
            reservas

          }))
          .sort(
            (a, b) =>
              b.reservas - a.reservas
          )
          .slice(0, 5);

      setUsuariosData(
        usuariosFormatados
      );

    } catch (err) {

      console.error(err);

    }

  }

  useEffect(() => {

    buscarDados();

  }, []);

  const COLORS = [
    "#b30000",
    "#d94b4b",
    "#8d0000",
    "#ff7373",
    "#5c0000"
  ];

  return(

    <>

      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* PAGE */}

      <div className="estatistica-page">

        {/* TOPO */}

        <div className="reserva-topo">

          <button
            className="btn-voltar"
            onClick={() =>
              navigate(-1)
            }
          >
            ← Voltar
          </button>

        </div>


        <h1 className="titulo-page">
          Estatísticas das Reservas
        </h1>

        <div className="cards-grid">

          {/* HORÁRIOS */}

          <div className="grafico-card">

            <h2>
              Horários Mais Reservados
            </h2>

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <BarChart
                data={horariosData}
              >

                <CartesianGrid
                  strokeDasharray="3 3"
                />

                <XAxis dataKey="hora" />

                <YAxis />

                <Tooltip />

                <Bar
                  dataKey="total"
                  fill="#b30000"
                  radius={[8,8,0,0]}
                />

              </BarChart>

            </ResponsiveContainer>

          </div>

          {/* ESPORTES */}

          <div className="grafico-card">

            <h2>
              Esportes Mais Reservados
            </h2>

            <ResponsiveContainer
              width="100%"
              height={300}
            >

              <PieChart>

                <Pie
                  data={esportesData}
                  dataKey="value"
                  nameKey="name"
                  outerRadius={110}
                  label
                >

                  {
                    esportesData.map(
                      (entry, index) => (

                      <Cell
                        key={index}
                        fill={
                          COLORS[
                            index %
                            COLORS.length
                          ]
                        }
                      />

                    ))
                  }

                </Pie>

                <Tooltip />

              </PieChart>

            </ResponsiveContainer>

          </div>

          {/* MESES */}

          <div className="grafico-card full-width">

            <h2>
              Comparativo de Reservas por Mês
            </h2>

            <ResponsiveContainer
              width="100%"
              height={350}
            >

              <LineChart
                data={mesesData}
              >

                <CartesianGrid
                  strokeDasharray="3 3"
                />

                <XAxis dataKey="mes" />

                <YAxis />

                <Tooltip />

                <Line
                  type="monotone"
                  dataKey="reservas"
                  stroke="#b30000"
                  strokeWidth={4}
                />

              </LineChart>

            </ResponsiveContainer>

          </div>

          {/* RANKING */}

          <div className="grafico-card full-width">

            <h2>
              Usuários com Mais Reservas
            </h2>

            <div className="usuarios-ranking">

              {
                usuariosData.map(
                  (u, index) => (

                  <div
                    key={index}
                    className="usuario-item"
                  >

                    <div>

                      <span className="usuario-posicao">
                        #{index + 1}
                      </span>

                      <span className="usuario-nome">
                        {u.nome}
                      </span>

                    </div>

                    <span className="usuario-reservas">
                      {u.reservas} reservas
                    </span>

                  </div>

                ))
              }

            </div>

          </div>

        </div>

      </div>


      {/* FOOTER */}
<footer className="footer">

<div className="footer-top">

  <div className="footer-info">

    <h3>
      Fatec Sorocaba
    </h3>

    <p>
      Av. Eng. Carlos Reinaldo Mendes,
      2015 - Alto da Boa Vista
    </p>

    <p>
      Sorocaba/SP - CEP: 18013-280
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Telefone
    </h3>

    <p>
      (15) 3238-5266
    </p>

  </div>

  <div className="footer-info">

    <h3>
      Horário de funcionamento
    </h3>

    <p>
      Seg. a Sex. das 07:30 às 22:30
    </p>

    <p>
      Sáb. 07:40 às 13:00
    </p>

  </div>

  <div className="footer-social">

    <a href="#">
      F
    </a>

    <a href="#">
      Insta
    </a>

    <a href="#">
      LkdIn
    </a>

    <a href="#">
      YT
    </a>

  </div>

</div>

<div className="footer-bottom">

  <p>
    © 2026 - Centro Paula Souza -
    Todos os direitos reservados.
  </p>

  <p>
    Desenvolvido para o TCC.
  </p>

</div>

</footer>

    </>

  )

}

export default Estatisticas;