import './style.css'
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import Perfil from '../../assets/perfil.png'
import Basquete from '../../assets/basquete.jpg'
import Futsal from '../../assets/futsal.jpg'
import Handebol from '../../assets/handebol.jpg'
import Volei from '../../assets/volei.jpg'

function Home() {

  const navigate = useNavigate();

  const images = [Futsal, Volei, Basquete, Handebol];

  const [index, setIndex] = useState(0);

  const token = localStorage.getItem("token");

  const user = localStorage.getItem("user");

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  useEffect(() => {

    const interval = setInterval(() => {

      setIndex(prev =>
        (prev + 1) % images.length
      );

    }, 4000);

    return () => clearInterval(interval);

  }, []);

  return (

    <>

      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* HERO */}

      <div className="home-content">

        {/* CAROUSEL */}

        <div className="carousel-section">

          <div className="carousel-container">

            <img
              src={images[index]}
              alt="carousel"
              className="carousel-image"
            />

          </div>

          {/* DOTS */}

          <div className="dots">

            {

              images.map((_, i) => (

                <div
                  key={i}
                  className={`dot ${
                    i === index
                      ? "active"
                      : ""
                  }`}
                  onClick={() => setIndex(i)}
                />

              ))

            }

          </div>

        </div>

        {/* TEXTO */}

        <div className="info-section">

          <h1>
            Reserve sua Quadra
          </h1>

          <p>

            Para reservar horários,
            participar de partidas
            abertas e gerenciar suas reservas,
            realize login ou crie sua conta.

          </p>

          <div className="info-buttons">

            <Link
              to="/login"
              className="btn-login-home"
            >
              Fazer Login
            </Link>

            <Link
              to="/cadastro"
              className="btn-cadastro-home"
            >
              Criar Conta
            </Link>

          </div>

        </div>

      </div>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone:
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento:
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              <i className="fab fa-facebook-f"></i>
            </a>

            <a href="#">
              <i className="fab fa-instagram"></i>
            </a>

            <a href="#">
              <i className="fab fa-linkedin-in"></i>
            </a>

            <a href="#">
              <i className="fab fa-youtube"></i>
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>

    </>

  );

}

export default Home;