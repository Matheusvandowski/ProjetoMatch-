import './style.css'

import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import axios from "axios";

import Perfil from '../../assets/perfil.png'

function Login() {

  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  // ==============================
  // DADOS USUÁRIO
  // ==============================

  const token =
    localStorage.getItem("token");

  const user =
    localStorage.getItem("user");

  // ==============================
  // CLICK PERFIL
  // ==============================

  function handleUserClick() {

    if (token) {

      navigate("/perfil");

    } else {

      navigate("/login");

    }

  }

  // ==============================
  // LOGIN
  // ==============================

  async function logar(e) {

    e.preventDefault();

    try {

      const response = await axios.post(
        "http://localhost:3000/login",
        {
          email,
          senha
        }
      );

      // TOKEN
      localStorage.setItem(
        "token",
        response.data.token
      );

      // NOME
      localStorage.setItem(
        "nome",
        response.data.nome
      );

      // USER
      localStorage.setItem(
        "user",
        email
      );

      // TIPO
      localStorage.setItem(
        "tipo",
        response.data.tipo
      );

      alert(
        "Login realizado com sucesso!"
      );

      navigate("/");

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao fazer login"
      );

    }

  }

  return (

    <div className="page-container">

      {/* HEADER */}

      <div className="header">

        {/* ESQUERDA */}

        <div className="header-left">

          <Link
            to="/"
            className="logo-area"
          >

            <span className="logo1">
              Fatec Sorocaba
            </span>

            <span className="logo-sub">
              José Crespo Gonzales
            </span>

          </Link>

        </div>

        {/* CENTRO */}

        <div className="header-center">

          <Link to="/">
            Home
          </Link>

          <Link to="/reservar-horario">
            Reservar Horários
          </Link>

          <Link to="/visualizar-horario">
            Horários Agendados
          </Link>

          <Link to="/reportar-atividades">
            Reportar Atividades
          </Link>

        </div>

        {/* DIREITA */}

        <div className="header-right">

          <img
            src={Perfil}
            alt="perfil"
          />

          <span
            onClick={handleUserClick}
            style={{ cursor: "pointer" }}
          >

            {
              token
                ? user?.split("@")[0]
                : "Login"
            }

          </span>

        </div>

      </div>

      {/* LOGIN */}

      <main className="main-content">

        <div className="login-container">

          <form
            className="login-box"
            onSubmit={logar}
          >

            <h1>
              Login
            </h1>

            <input
              type="email"
              placeholder="Digite seu email"
              value={email}
              onChange={(e) =>
                setEmail(
                  e.target.value
                )
              }
              required
            />

            <input
              type="password"
              placeholder="Digite sua senha"
              value={senha}
              onChange={(e) =>
                setSenha(
                  e.target.value
                )
              }
              required
            />

            {/* ESQUECI SENHA */}

            <p className="esqueci-senha-link">

              <Link to="/senha">
                Esqueci minha senha
              </Link>

            </p>

            <button type="submit">
              Entrar
            </button>

            {/* CADASTRO */}

            <p className="cadastro-link">

              Não possui conta?{" "}

              <Link to="/cadastro">
                Cadastre-se
              </Link>

            </p>

          </form>

        </div>

      </main>

      {/* FOOTER */}

      <footer className="footer">

        <div className="footer-top">

          <div className="footer-info">

            <h3>
              Fatec Sorocaba
            </h3>

            <p>
              Av. Eng. Carlos Reinaldo Mendes,
              2015 - Alto da Boa Vista
            </p>

            <p>
              Sorocaba/SP - CEP: 18013-280
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Telefone
            </h3>

            <p>
              (15) 3238-5266
            </p>

          </div>

          <div className="footer-info">

            <h3>
              Horário de funcionamento
            </h3>

            <p>
              Seg. a Sex. das 07:30 às 22:30
            </p>

            <p>
              Sáb. 07:40 às 13:00
            </p>

          </div>

          <div className="footer-social">

            <a href="#">
              F
            </a>

            <a href="#">
              Insta
            </a>

            <a href="#">
              LkdIn
            </a>

            <a href="#">
              YT
            </a>

          </div>

        </div>

        <div className="footer-bottom">

          <p>
            © 2026 - Centro Paula Souza -
            Todos os direitos reservados.
          </p>

          <p>
            Desenvolvido para o TCC.
          </p>

        </div>

      </footer>

    </div>

  )

}

export default Login;