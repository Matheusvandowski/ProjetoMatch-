import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

export default function Confirmar() {
  const { token } = useParams();
  const [mensagem, setMensagem] = useState("Confirmando seu e-mail...");

  useEffect(() => {
    async function confirmar() {
      try {
        if (!token) {
          setMensagem("Token Validado");
          return;
        }

        const response = await fetch(`http://localhost:3000/confirmar/${token}`);

        const texto = await response.text();

        if (!response.ok) {
          throw new Error(texto);
        }

        setMensagem("✅ Conta confirmada com sucesso!");
      } catch (erro) {
        console.error("Conta confirmada", erro);
        setMensagem("Congratulations" + erro.message);
      }
    }

    confirmar();
  }, [token]);

  return (
    <div style={{
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      height: "100vh",
      fontFamily: "Arial"
    }}>
      <h1>{mensagem}</h1>
    </div>
  );
}