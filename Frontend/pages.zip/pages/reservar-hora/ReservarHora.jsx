import './style.css'
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function ReservarHora() {

  const navigate = useNavigate();

  const [data, setData] = useState("");

  const [horaSelecionada, setHoraSelecionada] =
    useState("");

  const [quadras, setQuadras] =
    useState([]);

  const [quadraSelecionada, setQuadraSelecionada] =
    useState("");

  const [horariosReservados, setHorariosReservados] =
    useState([]);

  const [partidasAbertas, setPartidasAbertas] =
    useState([]);

  const horas = [
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00",
    "20:00",
    "21:00"
  ];

  /* ================================
     BUSCAR QUADRAS
  ================================= */

  useEffect(() => {

    buscarQuadras();

  }, []);

  async function buscarQuadras() {

    try {

      const res = await axios.get(
        "http://localhost:3000/quadras"
      );

      console.log(
        "QUADRAS:",
        res.data
      );

      const quadrasAtivas =
        Array.isArray(res.data)
          ? res.data.filter(
              (q) =>
                Number(q.disponibilidade) === 1
            )
          : [];

      setQuadras(quadrasAtivas);

      if (quadrasAtivas.length > 0) {

        setQuadraSelecionada(
          quadrasAtivas[0].id
        );

      }

    } catch (err) {

      console.error(
        "ERRO QUADRAS:",
        err
      );

      alert(
        "Erro ao carregar quadras"
      );

    }

  }

  /* ================================
     BUSCAR HORÁRIOS RESERVADOS
  ================================= */

  useEffect(() => {

    if (
      quadraSelecionada &&
      data
    ) {

      buscarHorariosReservados();

    }

  }, [quadraSelecionada, data]);

  async function buscarHorariosReservados() {

    try {

      console.log(
        "BUSCANDO:",
        quadraSelecionada,
        data
      );

      const res = await axios.get(
        `http://localhost:3000/agendamentos/${quadraSelecionada}/${data}`
      );

      console.log(
        "HORARIOS API:",
        res.data
      );

      const horarios =
        Array.isArray(res.data)
          ? res.data.map((item) => ({

              horario:
                String(
                  item.horario
                )
                .trim()
                .slice(0, 5),

              aberta:
                item.aberta,

              id_agendamento:
                item.id_agendamento,

              esporte:
                item.esporte

            }))
          : [];

      setHorariosReservados(
        horarios.map(
          (h) => h.horario
        )
      );

      const abertas =
        horarios.filter(
          (h) =>
            Number(h.aberta) === 1
        );

      setPartidasAbertas(
        abertas
      );

    } catch (err) {

      console.error(
        "ERRO HORARIOS:",
        err
      );

      setHorariosReservados([]);

      setPartidasAbertas([]);

    }

  }

  /* ================================
     VERIFICAR PARTIDA ABERTA
  ================================= */

  function buscarPartidaAberta(hora) {

    return partidasAbertas.find(
      (p) => p.horario === hora
    );

  }

  /* ================================
     ENTRAR PARTIDA
  ================================= */

  async function entrarPartida(
    idAgendamento
  ) {

    try {

      const token =
        localStorage.getItem("token");

      if (!token) {

        alert(
          "Faça login primeiro"
        );

        navigate("/login");

        return;

      }

      await axios.post(
        "http://localhost:3000/partida/participar",
        {
          id_agendamento:
            idAgendamento
        },
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      alert(
        "Você entrou na partida!"
      );

      navigate(
        `/partida/${idAgendamento}`
      );

    } catch (err) {

      console.error(err);

      alert(
        err.response?.data ||
        "Erro ao entrar na partida"
      );

    }

  }

  /* ================================
     RESERVAR
  ================================= */

  async function reservar() {

    if (
      !data ||
      !horaSelecionada ||
      !quadraSelecionada
    ) {

      alert(
        "Selecione quadra, data e hora"
      );

      return;

    }

    try {

      const token =
        localStorage.getItem("token");

      if (!token) {

        alert(
          "Faça login primeiro"
        );

        navigate("/login");

        return;

      }

      console.log(
        "ENVIANDO RESERVA:",
        {
          id_quadra:
            Number(quadraSelecionada),

          dt_agendamento:
            data,

          hr_agendamento:
            horaSelecionada
        }
      );

      const res = await axios.post(
        "http://localhost:3000/reservar",
        {
          id_quadra:
            Number(quadraSelecionada),

          dt_agendamento:
            data,

          hr_agendamento:
            horaSelecionada
        },
        {
          headers: {
            Authorization:
              `Bearer ${token}`
          }
        }
      );

      console.log(
        "RESPOSTA:",
        res.data
      );

      alert(
        "Reserva realizada!"
      );

      setHoraSelecionada("");

      buscarHorariosReservados();

      navigate(
        "/visualizar-horario"
      );

    } catch (err) {

      console.error(
        "ERRO RESERVA:",
        err
      );

      if (err.response) {

        console.log(
          "ERRO BACK:",
          err.response.data
        );

        alert(
          err.response.data
        );

      } else {

        alert(
          "Erro ao reservar"
        );

      }

    }

  }

  return (

    <div className="reserva-container">

      <div className="reserva-box">

        <h1>
          Reservar Hora
        </h1>

        {/* ================================
            SELECT QUADRA
        ================================= */}

        <select
          value={quadraSelecionada}
          onChange={(e) =>
            setQuadraSelecionada(
              e.target.value
            )
          }
        >

          {quadras.length === 0 && (

            <option>
              Nenhuma quadra disponível
            </option>

          )}

          {quadras.map((quadra) => (

            <option
              key={quadra.id}
              value={quadra.id}
            >
              {quadra.nome}
            </option>

          ))}

        </select>

        {/* ================================
            DATA
        ================================= */}

        <input
          type="date"
          value={data}
          onChange={(e) =>
            setData(
              e.target.value
            )
          }
        />

        {/* ================================
            HORÁRIOS
        ================================= */}

        <div className="horas-grid">

          {horas.map((hora) => {

            const reservado =
              horariosReservados.includes(
                hora
              );

            const partidaAberta =
              buscarPartidaAberta(
                hora
              );

            return (

              <div
                key={hora}
                className="hora-wrapper"
              >

                <button
                  type="button"
                  disabled={
                    reservado &&
                    !partidaAberta
                  }
                  className={
                    reservado
                      ? partidaAberta
                        ? "hora aberta"
                        : "hora reservada"
                      : horaSelecionada === hora
                      ? "hora ativa"
                      : "hora"
                  }
                  onClick={() => {

                    if (
                      partidaAberta
                    ) {

                      entrarPartida(
                        partidaAberta.id_agendamento
                      );

                      return;

                    }

                    if (!reservado) {

                      setHoraSelecionada(
                        hora
                      );

                    }

                  }}
                >

                  {partidaAberta
                    ? `${hora} - Entrar Partida`
                    : reservado
                    ? `${hora} - Ocupado`
                    : hora}

                </button>

                {partidaAberta && (

                  <div className="partida-info-aberta">

                    <span>
                      ⚽ {
                        partidaAberta.esporte ||
                        "Partida Aberta"
                      }
                    </span>

                  </div>

                )}

              </div>

            );

          })}

        </div>

        {/* ================================
            BOTÃO
        ================================= */}

        <button
          className="btn-confirmar"
          onClick={reservar}
        >
          Confirmar Reserva
        </button>

      </div>

    </div>

  );

}

export default ReservarHora;